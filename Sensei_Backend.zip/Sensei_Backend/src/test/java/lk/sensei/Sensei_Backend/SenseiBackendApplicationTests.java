package lk.sensei.Sensei_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenseiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
