package lk.sensei.Sensei_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenseiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenseiBackendApplication.class, args);
	}

}
